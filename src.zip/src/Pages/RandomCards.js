import React from 'react'

function RandomCards() {
  return (
    <div>
      <h1> random cards</h1>
    </div>
  )
}

export default RandomCards
