import React from 'react'

function CardsList() {
  return (
    <div>
      <h1>CARDLIST</h1>
    </div>
  )
}

export default CardsList
