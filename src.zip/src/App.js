import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./Pages/Home";
import CardsList from "./Pages/CardsList";
import RandomCards from "./Pages/RandomCards";

import SearchBar from "./SearchBar";
import cardsInfo from "./CardsInfo";
import Modal from "./components/Modal";
import Footer from "./Footer";
import ImageComponent from "./components/ImageComponent";
import NavBar from "./NavBar";
import Links from "./Links";

function App() {
  const [cardName, setCardName] = useState("");
  const [modalCard, setModalCard] = useState(null);

  const filteredCards = cardsInfo.filter((card) => card.name === cardName);

  const [modal, setModal] = useState(false);

  const toggleModal = (card) => {
    setModal(!modal);
    setModalCard({
      name: card.name,
      img: card.img,
      yes: card.yes,
      default: card.default,
      revers: card.revers,
      relations: card.relations,
      career: card.career,
      health: card.health,
    });
  };

  if (modal) {
    document.body.classList.add("active-modal");
  } else {
    document.body.classList.remove("active-modal");
  }

  return (
    <Router>
      <div className="App">
        <NavBar>
          <SearchBar setCardName={setCardName} />
          <Links />
        </NavBar>


        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cardsList" element={<CardsList />} />
          <Route path="/randomCards" element={<RandomCards />} />
        </Routes>

        <main className="">
          <ul className="card-container">
            {cardName === "" // Check if cardName is empty
              ? cardsInfo.map((card) => (
                  <li
                    key={card.id}
                    className="card"
                    onClick={() => toggleModal(card)}
                  >
                    <ImageComponent src={card.img} alt={card.name} />
                  </li>
                ))
              : filteredCards.map((card) => (
                  <li
                    key={card.id}
                    className="card"
                    onClick={() => toggleModal(card)}
                  >
                    <ImageComponent src={card.img} alt={card.name} />
                  </li>
                ))}
          </ul>

          {modal && <Modal toggleModal={toggleModal} card={modalCard} />}
        </main>

        <footer>
          <Footer />
        </footer>
      </div>
    </Router>
  );
}

export default App;
