import React from "react";

function Footer() {
  return (
    <div className="footer-container">
      <p><a href="https://perehudovnikita.online/">perehudov.com</a></p>
    </div>
  );
}

export default Footer;
