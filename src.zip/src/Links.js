import React from "react";
import { Link, useLocation } from "react-router-dom";

function Links() {
  return (
    <div className="links">
      <Link to="/">Home</Link>
      <Link to="/cardsList">Cards List</Link>
      <Link to="/randomCards">Random Cards</Link>
    </div>
  );
}

export default Links;
